"""Init file for brain_games/scripts."""
