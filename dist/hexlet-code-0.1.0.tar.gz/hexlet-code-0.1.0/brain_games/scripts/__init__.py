"""Init file for brain_games.py."""
